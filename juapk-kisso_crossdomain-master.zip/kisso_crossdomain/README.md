#kisso_crossdomain

kisso 跨域演示 demo 同时需要看 demo [kisso_SpringMvc 演示 demo](http://git.oschina.net/juapk/kisso_springmvc)  逻辑


[kisso 帮助文档下载](http://git.oschina.net/baomidou/kisso/attach_files)


> 技术讨论 QQ 群 235079513 

[kisso 依赖 jars](http://git.oschina.net/baomidou/kisso/wikis/kisso-%E4%BE%9D%E8%B5%96%E5%8C%85-jars)

[kisso_Jfinal 演示 demo](http://git.oschina.net/juapk/kisso_jfinal)

[kisso_ApiServer 移动端 演示 demo](http://git.oschina.net/juapk/kisso_apiserver)

[kisso_crossdomain 跨域演示 demo](http://git.oschina.net/juapk/kisso_crossdomain)


捐赠 kisso
====================

![捐赠 kisso](http://git.oschina.net/uploads/images/2015/1222/211207_0acab44e_12260.png "支持一下kisso")


### 配置 HOSTS 
127.0.0.1 sso.test.com

127.0.0.1 my.web.com


### 跨域测试
1、先登录  sso.test.com:8080/index.html  跨域 my.web.com:8090/index.html

2、访问 my.web.com:8090/index.html 自动跨域


### 跨域登录（原理）
--------------------------------------------

![GitHub](https://raw.githubusercontent.com/leqwang/kisso/master/images/cl.jpg "Kisso,crossdomain login")


关注我
====================
![程序员日记](http://git.oschina.net/uploads/images/2016/0121/093728_1bc1658f_12260.png "程序员日记")