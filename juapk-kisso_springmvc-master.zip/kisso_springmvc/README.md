#kisso_springmvc

SpringMvc 基于 kisso 的 sso 演示 demo


[kisso 帮助文档下载](http://git.oschina.net/baomidou/kisso/attach_files)


> 技术讨论 QQ 群 235079513 

http://baomidou.com/

http://www.oschina.net/p/kisso

[mybatis 增强工具包，简化 CURD 操作](http://git.oschina.net/baomidou/mybatis-plus)

[kisso 依赖 jars](http://git.oschina.net/baomidou/kisso/wikis/kisso-%E4%BE%9D%E8%B5%96%E5%8C%85-jars)

[kisso_Jfinal 演示 demo](http://git.oschina.net/juapk/kisso_jfinal)

[kisso_SpringMvc 演示 demo](http://git.oschina.net/juapk/kisso_springmvc)

[kisso_crossdomain 跨域演示 demo](http://git.oschina.net/juapk/kisso_crossdomain)

[kisso_SpringMvc 演示 demo SpringMvc4.1.4 框架 ](http://git.oschina.net/juapk/SpringMvc4.1.4)


捐赠 kisso
====================

![捐赠 kisso](http://git.oschina.net/uploads/images/2015/1222/211207_0acab44e_12260.png "支持一下kisso")


（1）登录

<img alt="welcome" width="800" height="500" src="http://git.oschina.net/uploads/images/2015/0309/094616_1cf45332_12260.png">

（2）登录成功

<img alt="welcome" width="800" height="500" src="http://git.oschina.net/uploads/images/2015/0302/180138_590ee527_12260.png">

Kisso
====================
kisso  =  cookie sso

基于 Cookie 的 SSO 中间件，欢迎大家使用 kisso !! 

http://www.oschina.net/p/kisso


关注我
====================
![程序员日记](http://git.oschina.net/uploads/images/2016/0121/093728_1bc1658f_12260.png "程序员日记")