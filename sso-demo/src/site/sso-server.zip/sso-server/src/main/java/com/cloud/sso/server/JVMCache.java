package com.cloud.sso.server;

import java.util.HashMap;
import java.util.Map;

public class JVMCache {

    public static Map<String, String> TICKET_AND_NAME = new HashMap<String, String>();
}